import 'package:projeto_tutorial/dao/dao_entity.dart';

abstract class Cliente {
  int codigo;
  String endereco;
  String telefone;
  String email;

  Cliente({
    required this.codigo,
    required this.endereco,
    required this.telefone,
    required this.email,
  });
}

class ClientePessoaFisica extends Cliente {
  int cpf;
  String sexo;
  String nome;
  DateTime dataNascimento;

  ClientePessoaFisica({
    required super.codigo,
    required super.endereco,
    required super.telefone,
    required super.email,
    required this.cpf,
    required this.sexo,
    required this.nome,
    required this.dataNascimento,
  });
}

class Funcionario implements DaoEntity {
  int codigo;
  String nome;
  int cpf;
  String endereco;
  String telefone;
  String email;
  String cargo;

  Funcionario({
    required this.codigo,
    required this.nome,
    required this.cpf,
    required this.endereco,
    required this.telefone,
    required this.email,
    required this.cargo,
  });

  Funcionario.empty() : this(
    codigo: DaoEntity.idInvalido,
    nome: '',
    cpf: 0,
    endereco: '',
    telefone: '',
    email: '',
    cargo: '',
  );

  Funcionario.fromMap(Map<String, Object?> map) : this(
    codigo: map['codigo'] as int,
    nome: map['nome'] as String,
    cpf: map['cpf'] as int,
    endereco: map['endereco'] as String,
    telefone: map['telefone'] as String,
    email: map['email'] as String,
    cargo: map['cargo'] as String,
  );

  @override
  void fromMap(Map<String, Object?> map) {
    codigo = map['codigo'] as int;
    nome = map['nome'] as String;
    cpf = map['cpf'] as int;
    endereco = map['endereco'] as String;
    telefone = map['telefone'] as String;
    email = map['email'] as String;
    cargo = map['cargo'] as String;
  }

  @override
  int get id => codigo;

  @override
  Map<String, Object?> toMap() {
    var map = <String, Object?>{
      'codigo': codigo,
      'nome': nome,
      'cpf': cpf,
      'endereco': endereco,
      'telefone': telefone,
      'email': email,
      'cargo': cargo,
    };
    return map;
  }
}

class Venda {
  int codigo;
  DateTime dataVenda;
  double valorTotal;
  Funcionario vendedor;
  Cliente cliente;

  Venda({
    required this.codigo,
    required this.dataVenda,
    required this.valorTotal,
    required this.vendedor,
    required this.cliente,
  });
}
